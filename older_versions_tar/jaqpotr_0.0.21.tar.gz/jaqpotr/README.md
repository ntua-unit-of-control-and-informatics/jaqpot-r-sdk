# jaqpotr
This repository contains the finalized  R client for jaqpot
